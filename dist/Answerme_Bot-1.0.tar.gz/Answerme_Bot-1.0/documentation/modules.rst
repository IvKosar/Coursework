modules package
===============

Subpackages
-----------

.. toctree::

    modules.message_processing
    modules.my_multiset
    modules.questions_dict

Submodules
----------

modules\.get\_user\_id module
-----------------------------

.. automodule:: modules.get_user_id
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: modules
    :members:
    :undoc-members:
    :show-inheritance:
